# Todo

### File Server

* [x] Hallo Welt Server
* [x] Dummy HTML, CSS, JS Dateien erstellen
* [x] URL direkt in request.url parsen
* [x] Mit Dateien antworten (./)
* [x] Status Codes für readFile Fehler: 404, 403, 500
* [x] Pfade mit Ende / += index.html
* [x] Mimetypes einbinden und zurückgeben
* [x] Accesslist mit Block-Liste

### Login

* [x] users.json Datenbank
* [x] index.html um Login Formular action=?login method=post erweitern
* [x] /?login aus searchParams anzielen
* [x] getBody und getBodyParams integrieren
* [x] Login Body, BN & PW prüfen: 400, 403
* [x] Passwörter hashen (OPTIONAL)
* [x] Brute Force Attacken unterbinden (OPTIONAL)

### Session und Cookies

* [x] Session erstellen
* [x] getCookies
* [x] Session beim Start der Seite auslesen
* [x] /?logout aus searchParams vor /?login anzielen
* [x] login.html erstellen
* [x] Accesslist mit Login-Liste
* [x] Session verlängern
* [x] admin.html erstellen (OPTIONAL)
* [x] Accesslist mit Group-Liste (OPTIONAL)

### Registrierung

* [x] register.html erstellen und in index.html verlinken
* [x] Passwort Matching im Client prüfen (OPTIONAL)
* [x] /?register aus searchParams anzielen
* [x] Register Body, Existing User prüfen: 400, 409
* [x] Passwort Mindestlänge und Komplexität (OPTIONAL)
* [x] UUID und Passwort Hash berechnen
* [x] Benutzerdatenbank speichern

### JS in HTML

* [x] Implementation
* [x] Template Engine
