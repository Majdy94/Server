'use strict';

console.log('Hallo Welt im Browser!');
